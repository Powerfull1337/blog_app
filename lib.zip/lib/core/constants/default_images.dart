class DefaultImages {
  static const userImage = "assets/images/user_image.jpg";
}
