

class MessageConstants {

  static const noInternetConnection = "No internet connection";
  static const userNotLoggedIn = "User not logged in!";
}