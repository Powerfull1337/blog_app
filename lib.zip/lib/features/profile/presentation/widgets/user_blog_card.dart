import 'package:flutter/material.dart';

class UserBlogCard extends StatelessWidget {
  const UserBlogCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.red,
      height: 200,
      width: double.infinity,
    );
  }
}
